package com.example.labtest2.db

import androidx.room.*
import com.example.labtest1.db.LocationEntity

@Dao
interface LocationDao {
    @Query("SELECT * from location ORDER BY id DESC")
    fun getAllLocation(): List<LocationEntity>?

    @Insert
    fun insertLocation(locationEntity: LocationEntity?)

    @Delete
    fun deleteLocation(locationEntity: LocationEntity?)
    @Update
    fun updateLocation(locationEntity: LocationEntity?)
}
