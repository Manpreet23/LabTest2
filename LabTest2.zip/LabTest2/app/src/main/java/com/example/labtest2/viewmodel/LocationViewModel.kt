package com.example.labtest2.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.labtest1.db.LocationEntity
import com.example.labtest1.db.RoomAppDB

class LocationViewModel (app: Application) : AndroidViewModel(app) {
    lateinit var allLocations: MutableLiveData<List<LocationEntity>>
    init {

        allLocations = MutableLiveData()
    }
    fun getAllLocationObservers(): MutableLiveData<List<LocationEntity>>
    {
        return allLocations
    }

    fun getAllData()
    {
        val studentDao = RoomAppDB.getAppDatabase(getApplication())?.locationDao()
        val listStudents = studentDao?.getAllLocation()
        allLocations.postValue(listStudents)
    }

    fun insertLocationInfo(locationEntity: LocationEntity)
    {
        val locationDao = RoomAppDB.getAppDatabase(getApplication())?.locationDao()
        locationDao?.insertLocation(locationEntity)
        getAllData()
    }
    fun updateLocationInfo(locationEntity: LocationEntity)
    {
        val locationDao = RoomAppDB.getAppDatabase(getApplication())?.locationDao()
        locationDao?.updateLocation(locationEntity)
        getAllData()
    }

    fun deleteLocationInfo(locationEntity: LocationEntity)
    {
        val locationDao = RoomAppDB.getAppDatabase(getApplication())?.locationDao()
        locationDao?.deleteLocation(locationEntity)
        getAllData()
    }
}