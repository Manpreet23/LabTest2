package com.example.labtest2

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.lifecycle.ViewModelProviders
import com.example.labtest1.db.LocationEntity
import com.example.labtest2.viewmodel.LocationViewModel
import kotlinx.android.synthetic.main.activity_edit_page.*


class EditPage : AppCompatActivity(), View.OnClickListener {

    private var id: Int = 0
    lateinit var viewModel: LocationViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_edit_page)


        val et_title : EditText = findViewById(R.id.et_title)
        val et_subtitle : EditText = findViewById(R.id.et_subtitle)
        val et_latitude : EditText = findViewById(R.id.et_latitude)
        val et_longitude : EditText = findViewById(R.id.et_longitude)
        val iv_back : ImageView = findViewById(R.id.iv_back)
        val  btn_submit : Button = findViewById(R.id.btn_submit)
        val  btn_delete : Button = findViewById(R.id.btn_delete)

        check()

        viewModel = ViewModelProviders.of(this).get(LocationViewModel::class.java)
        btn_submit.setOnClickListener(this)
        btn_delete.setOnClickListener(this)
        iv_back.setOnClickListener(this)
    }

    private fun check() {
         id = intent.getIntExtra("id",0)
        val title = intent.getStringExtra("title")
        val latitude = intent.getDoubleExtra("latitude",0.0)
        val longitude = intent.getDoubleExtra("longitude",0.0)
        val subtitle = intent.getStringExtra("subtitle")

        et_title.setText(title)
        et_subtitle.setText(subtitle)
        et_latitude.setText(latitude.toString())
        et_longitude.setText(longitude.toString())

    }
    override fun onClick(p0: View?) {
        if (p0 != null) {
            when(p0.id) {
                R.id.btn_submit -> click()
                R.id.iv_back -> onBackPressed()
                R.id.btn_delete -> delete()
            }
        }
    }

    fun delete()
    {
        val location =  LocationEntity(id, "", "",0.0,0.0)
        viewModel.deleteLocationInfo(location)
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)

    }
    fun click()
    {

        val title = et_title.text.toString()
        val subtitle = et_subtitle.text.toString()
        val latitude : Double = et_latitude.text.toString().toDouble()
        val longitude : Double = et_longitude.text.toString().toDouble()



        val intent = Intent()
        intent.putExtra("id",id)
        intent.putExtra("title", title)
        intent.putExtra("subtitle", subtitle)
        intent.putExtra("latitude", latitude)
        intent.putExtra("longitude", longitude)

        setResult(Activity.RESULT_OK,intent)
        finish()


    }
}