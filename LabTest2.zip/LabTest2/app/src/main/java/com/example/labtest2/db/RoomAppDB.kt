package com.example.labtest1.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.labtest2.db.LocationDao

@Database(entities = [LocationEntity ::class],version = 1)
abstract class RoomAppDB : RoomDatabase() {
    abstract fun locationDao(): LocationDao?
    companion object
    {
        private var INSTANCE : RoomAppDB?= null

        fun getAppDatabase(context: Context) : RoomAppDB?
        {
            if(INSTANCE == null)
            {
                INSTANCE = Room.databaseBuilder<RoomAppDB>(context.applicationContext,RoomAppDB::class.java,"LocationDB")
                    .allowMainThreadQueries()
                    .build()

            }
            return INSTANCE
        }
    }
}