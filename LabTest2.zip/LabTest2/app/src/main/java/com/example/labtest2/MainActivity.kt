package com.example.labtest2

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.labtest1.db.LocationEntity
import com.example.labtest2.adapter.MarkerInfoWindowAdapter
import com.example.labtest2.viewmodel.LocationViewModel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions


class MainActivity : AppCompatActivity(), View.OnClickListener, OnMapReadyCallback
    {
        var id: Int = 0
    lateinit var mapFragment: SupportMapFragment
    var locationList = ArrayList<LocationEntity>()
    lateinit var googleMap: GoogleMap
    lateinit var viewModel: LocationViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_main)


        val iv_add : ImageView = findViewById(R.id.iv_add)
        mapFragment= supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)


        iv_add.setOnClickListener(this)
    }


    private fun addMarker()
    {
        for (i in locationList) {
           data(i)
        }
    }
    fun data(data: LocationEntity )
    {

        val location = LatLng(data.latitude,data.longitude)
        googleMap.addMarker(MarkerOptions().position(location).title(data.title).snippet(data.subtitle))
        googleMap.animateCamera(
            CameraUpdateFactory.newLatLngZoom(location,10f)
        )

        }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        viewmodelData()
        googleMap.setInfoWindowAdapter(MarkerInfoWindowAdapter(this))
    googleMap.setOnInfoWindowClickListener {
        val intent = Intent(this, EditPage::class.java)
        id = locationList.get(0).id
     for (value in locationList)
        {
            if (it.title.equals(value.title))
            {

                intent.putExtra("id", value.id)
                intent.putExtra("title",value.title)
                intent.putExtra("subtitle", value.subtitle)
                intent.putExtra("latitude", value.latitude)
                intent.putExtra("longitude",value.longitude)
                startActivityForResult(intent,2)
            }
        }

            }

    }
    override fun onClick(p0: View?) {
        val intent = Intent(this, EditPage::class.java)
        startActivityForResult(intent,1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 1 && resultCode == Activity.RESULT_OK  && data!=null)
        {

            val title = data?.getStringExtra("title")
            val subtitle = data?.getStringExtra("subtitle")
            val latitude = data?.getDoubleExtra("latitude",0.0)
            val longitude = data?.getDoubleExtra("longitude",0.0)

            val location =  LocationEntity(0, title, subtitle,latitude,longitude)
            viewModel.insertLocationInfo(location)
            Log.e("--New","new")

        }
        else  if (requestCode == 2 && resultCode == Activity.RESULT_OK  && data!=null)
        {
            googleMap.clear()

            val id = data?.getIntExtra("id",0)
            val title = data?.getStringExtra("title")
            val subtitle = data?.getStringExtra("subtitle")
            val latitude = data?.getDoubleExtra("latitude",0.0)
            val longitude = data?.getDoubleExtra("longitude",0.0)

            val location =  LocationEntity(id, title, subtitle,latitude,longitude)
            viewModel.updateLocationInfo(location)
            Log.e("--Update","update")

        }

    }



    private fun viewmodelData() {

        viewModel = ViewModelProviders.of(this).get(LocationViewModel::class.java)
        viewModel.getAllData()
        viewModel.getAllLocationObservers().observe(this, Observer {
            this.locationList = ArrayList(it)
            addMarker()

        })
    }




}